# VidaFiT Aí
Um microSaaS que gera planos de treino e dieta com base em dados do usuário usando IA.