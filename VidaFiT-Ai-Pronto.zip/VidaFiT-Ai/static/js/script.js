# static/js/script.js
